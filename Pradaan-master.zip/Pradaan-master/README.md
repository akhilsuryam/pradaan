# Pradan
 Java Web App for donation
 
 It has 3 roles:  
    &nbsp;&nbsp;1.&nbsp;Donator  
    &nbsp;&nbsp;2.&nbsp;Volunteer  
    &nbsp;&nbsp;3.&nbsp;NGO
 
 The web app connection NGO and Donator. Donator can choose from thee list what to donate and can donate to particular NGO.
 
 ### Requirements:
 
 JDK and JRE  
 Eclipse IDE(preferable)
 
 ### How to run?
 
 Simply open index.html in WebContent folder
